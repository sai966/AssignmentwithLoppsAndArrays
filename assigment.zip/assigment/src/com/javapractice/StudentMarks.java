package com.javapractice;

public class StudentMarks {

	public static void main(String[] args) {
		int[] studentMarks = new int[] {78,12,89,55,35};
		for(int i=0;i<studentMarks.length;i++)
		{
			if(studentMarks[i]>80)
			{
				System.out.println("Student Mark's more than 80 is "+studentMarks[i]);
			}
		}

	}

}
