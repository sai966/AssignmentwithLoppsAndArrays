package com.javapractice;

public class Average {

	public static void main(String[] args) {
		int a = 10,b =111,c = 8989,d = 7876 ;
		double x = 90.78,avg;
		avg = (a + b + c + d + x)/5 ;  
		System.out.println("The average of numbers is: "+avg );  
	}

}
