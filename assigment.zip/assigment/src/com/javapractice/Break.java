package com.javapractice;

public class Break {

	public static void main(String[] args) {
			int[] numbers = new int[] {12,34,66,85,900};
			for(int i=0;i<numbers.length;i++)
			{
				if(numbers[i] == 85)
				{
					System.out.println("number is equal to 85");
					break;
				}
			}
	}

}