package com.javapractice;

public class StringArrayWithBreak {

	public static void main(String[] args) {
		String[] name = new String[]{"Java","JavaScript","Selenium","Python","Mukesh"};
		for(int i=0;i<name.length;i++)
		{
			if(name[i].equalsIgnoreCase("Selenium"))
			{
				System.out.println("We find the name Selenium");
				break;
			}
		}

		}
	}
