package com.javapractice;

public class Breakstring {

	public static void main(StringArrayWithBreak[] args) {
		// TODO Auto-generated method stub

	}

}
