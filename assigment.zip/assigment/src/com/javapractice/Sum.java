package com.javapractice;

public class Sum {

	public static void main(String[] args) {
		int a = 10,b =111,c = 8989,d = 7876 ;
		double x = 90.78,sum;
		sum = a + b + c + d + x ;  
		System.out.println("The sum of numbers is: "+sum);  

	}

}
